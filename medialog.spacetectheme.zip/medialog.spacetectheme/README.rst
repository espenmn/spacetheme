s==============================================================================
medialog.spacetectheme
==============================================================================

Tell me what your product does

Features
--------

- A Plone 5 diazo theme


Examples
--------

This add-on can be seen in action at the following sites:
spacetec.no




Installation
------------

Install medialog.spacetectheme by adding it to your buildout::

    [buildout]

    ...

    eggs =
        medialog.spacetectheme


and then running ``bin/buildout``


Contribute
----------

- Issue Tracker: https://github.com/collective/medialog.spacetectheme/issues
- Source Code: https://github.com/collective/medialog.spacetectheme
- Documentation: https://docs.plone.org/foo/bar


Support
-------

If you are having issues, please let us know.
espen@medialog.no


License
-------

The project is licensed under the GPLv2.
